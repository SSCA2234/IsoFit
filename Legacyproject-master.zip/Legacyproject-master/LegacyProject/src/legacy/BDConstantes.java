package legacy;

public class BDConstantes {
	final static String DRIVER ="jdbc:derby";
	final static String CONNECTION_STRING ="jdbc:derby:iso1_db;create=true";
	final static String DBNAME ="iso1_db";
	final static String DBUSER ="admin";
	final static String DBPASS ="admin";
}
